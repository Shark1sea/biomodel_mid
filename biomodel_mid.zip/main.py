def main():
    print("Hello from biomodel-mid!")


if __name__ == "__main__":
    main()
